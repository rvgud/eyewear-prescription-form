=== Eyewear prescription form ===
Contributors: dugudlabs
Donate link: https://www.dugudlabs.com/specfit/eyewear-prescription-form
Tags: eyewear,prescription,glasses,lens,pd,dualpd,singlepd,coating,pdcalculator,measure-my-pd, pd-master,bifocal,optician,specfit,jewelfit
Requires at least: 3.0.1
Requires PHP: 5.0
Tested up to: 5.4.1
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Eyewear prescription form plugin enabled you to add as many as lens, glasses and lens coatings to your products.

== Description ==
Eyewear prescription form plugin is designed to use with woocommerece.
Every eyewear product will have a option to add required lens type,glass type and lens coating.Also customers can add their description given by their doctor.
No manual code needed, everything works smooth without minimal efforts required.

==Premium Features==
* Update Image of lens
* Update Name of lens
* Update description of lens
* Add price for lens/SPH/CYL/ADD/PD
* Disable/Eable lens to show on product page
* Add unlimited lenes using Add New Panel.
* Full Customization avaliable.
* Customers can upload their prescription form image in order.
* Add unlimited glass types and lens coatings using Add New Panel.
* Free lifetime Support
Checkout at:- [Eyewear Prescription Form](https://www.dugudlabs.com/specfit/eyewear-prescription-form)
== Installation ==

1. Upload `eyewear_prescription_form.zip` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. You will see EPF option in admin panel.
4. Under EPF option: You can manage lenses,glassess,coating etc.

== Frequently Asked Questions ==

= How it works? =

Our Development team’s main focus was to make this plugin more easy to use and customize.So we have designed this plugin in a way that only one step can reach your requirements.You just have to go to EPF admin page and update len options.That’s it. It will automatically render a Add Prescription button on that product.

== Screenshots ==

1. Admin Page: Glass Types
2. Admin Page: Lens Types
3. Admin Page: Lens Coating Types
4. Frontend Page: Product Page-Add Recipe Button
5. Frontend Page: Enter Prescription Steps
6. Frontend Page: Step-1 Enter Glass Type And Prescription
7. Frontend Page: Step-1 Enter PD
8. Frontend Page: Step-1 Measure PD
9. Frontend Page: Step-2 Enter Lens Type
10. Frontend Page: Step-3 Enter Coating Type
11. Frontend Page: Cart Page

== Changelog ==

= 1.0 =
* First Change


== Upgrade Notice ==
NA
